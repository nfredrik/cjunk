control system web interface 
----------------------------

web server : boa


files at /var/www

- index.html
- nial.jpg


files at /usr/lib/cgi-bin

- index.cgi               # main script
- commands.cgi            # stop hvps, init_hw, rem_single, reset_seq_pointers, etc
- logs.cgi                # main page for application and driver logs and reading regs
- log0.cgi log1.cgi
- driver.cgi
- hw.cgi